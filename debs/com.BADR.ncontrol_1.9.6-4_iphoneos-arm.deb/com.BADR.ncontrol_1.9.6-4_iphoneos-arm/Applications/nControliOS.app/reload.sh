#!/bin/bash

killall nControliOS & lsdtrip launch com.nito.ncontrol
